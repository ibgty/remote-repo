#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#define MAX 20
typedef struct task{
	void(*fun) (int);
	int arg;
	struct task* next;
}task;
typedef struct{
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	int busywork;
	pthread_t tid[MAX];
	task*head;
}pool;
pool*pol;
void work_thread();
void pool_init(){
	pol=(pool*)malloc(sizeof(pool));
	pthread_mutex_init(&pol->mutex,NULL);
	pthread_cond_init(&pol->cond,NULL);
	pol->busywork=0;
	for(int i=0;i<20;i++){
		pthread_create(&pol->tid[i],NULL,(void*)work_thread,NULL);
	}
	pol->head=NULL;
}	
void work_thread(){
	while(1){
	pthread_mutex_lock(&pol->mutex);
	//while(NULL==pol->head)
	pthread_cond_wait(&pol->cond,&pol->mutex);
	task*member=pol->head;
	pol->head=pol->head->next;
	pthread_mutex_unlock(&pol->mutex);
	member->fun(member->arg);
	pol->busywork--;
	}
}
void print(int arg){
	printf("task is %d\n",arg);
}
void add_task(int arg){
	pthread_mutex_lock(&pol->mutex);
	while(pol->busywork>=MAX){
		pthread_mutex_unlock(&pol->mutex);
		sleep(1);
		pthread_mutex_lock(&pol->mutex);
	}
	pthread_mutex_unlock(&pol->mutex);
	task*ta=(task*)malloc(sizeof(task));
	ta->fun=print;
	ta->arg=arg;
	pthread_mutex_lock(&pol->mutex);
	if(NULL==pol->head){
	pol->head=ta;
	ta->next=NULL;
	}else{
		task*member=pol->head;
		while(member->next){
			member=member->next;
		}
		member->next=ta;
	}
	pthread_cond_signal(&pol->cond);
	pol->busywork++;
	pthread_mutex_unlock(&pol->mutex);
}
void destory(){
	
	pthread_mutex_destroy(&pol->mutex);
	perror("mutex");
pthread_cond_destroy(&pol->cond);
	perror("mutex");
	task*member=pol->head;
	while(member)
	{
		pol->head=member->next;
		free(member);
		member=pol->head;
	}
	free(pol);
}
void main(){
	pool_init();
	sleep(3);
	for(int i=0;i<40;i++){
		add_task(i);
	}
		sleep(3);
	
	destory();
}//bug cond can't destroy
