#include"net.h"
#include<unistd.h>
#include<string.h>
#include<errno.h>
#include<stdio.h>
#include<stdlib.h>
void work(int fd,char*buf,int buf_len){
	char buff[SR_LEN];
	struct sockaddr_in recv_addr;
	socklen_t len=sizeof(struct sockaddr);
	int ret;
	struct sockaddr_in send_addr;
	send_addr.sin_family=AF_INET;
	send_addr.sin_port=htons(SERVER_PORT);
	inet_pton(AF_INET,SERVER_ADDR,&send_addr.sin_addr);
	while(1){
		while(sendto(fd,buf,buf_len,0,(struct sockaddr*)&send_addr,len)<0);
		printf("send:%s\n",buf);
		do{
			ret=recvfrom(fd,buff,SR_LEN-1,0,(struct sockaddr*)&recv_addr,&len);
		}while(ret<0&&EINTR==errno);
		if(!ret)
			break;
		printf("receive data:%s\n",buff);
		printf("receive address:%s\n",inet_ntoa(recv_addr.sin_addr));
		printf("receive port:%d\n",ntohs(recv_addr.sin_port));
	}
}
void main(int argc,char* argv[]){
	int fd=socket(AF_INET,SOCK_DGRAM,0);
	work(fd,argv[1],strlen(argv[1]));
	close(fd);
	}

