#include<sys/socket.h>
#include<netinet/in.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#define SERVER_ADDR "192.168.137.130"
#define SERVER_PORT 10002
#define CLIENT_ADDR "192.168.137.130"
#define CLIENT_PORT 10022 
#define SR_LEN 100
#define CR_LEN 100
