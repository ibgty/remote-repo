#include"net.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
void main(){
	int fd=socket(AF_INET,SOCK_DGRAM,0);
	struct sockaddr_in server,client;
	server.sin_family=AF_INET;
	server.sin_port=htons(SERVER_PORT);
	server.sin_addr.s_addr=htonl(INADDR_ANY);
	//server.sin_addr.s_addr=inet_addr(SERVER_ADDR);
	bind(fd,(struct sockaddr*)&server,sizeof(struct sockaddr));
	perror("");
	char buf[10]="hello wor";	
	socklen_t len=sizeof(struct sockaddr);
	int ret;
	struct sockaddr_in recv_client;
	char addr[100];
	while(1){
	do{
		ret=recvfrom(fd,buf,sizeof(buf),0,(struct sockaddr*)&recv_client,&len);
	}while(ret<0);
	if(!ret){
		break;
	}	
	memset(addr,0,sizeof(addr));
	printf("rec %s\n",buf);
	inet_ntop(AF_INET,&recv_client.sin_addr.s_addr,addr,sizeof(struct sockaddr));
	printf("data:%s,port:%d,addr:%s\n",buf,htons(client.sin_port),addr);
		sendto(fd,buf,sizeof(buf),0,(struct sockaddr*)&recv_client,sizeof(struct sockaddr));
	printf("send %s\n",buf);
	memset(buf,0,sizeof(buf));
	}
	close(fd);
}
