#include"net.h"
#include<unistd.h>
#include<string.h>
#include<errno.h>
#include<stdio.h>
#include<stdlib.h>
void work(int fd,char*buf,int buf_len){
	char buff[SR_LEN];
	struct sockaddr_in recv_addr;
	socklen_t len=sizeof(struct sockaddr);
	int ret;
	while(1){
		do{
			ret=recvfrom(fd,buff,SR_LEN-1,0,(struct sockaddr*)&recv_addr,&len);
		}while(ret<0&&EINTR==errno);
		if(!ret)
			break;
		printf("receive data:%s\n",buff);
		printf("receive address:%s\n",inet_ntoa(recv_addr.sin_addr));
		printf("receive port:%d\n",ntohs(recv_addr.sin_port));
		while(sendto(fd,buf,buf_len,0,(struct sockaddr*)&recv_addr,len)<0);
		printf("send:%s\n",buf);
	}
}
void main(int argc,char* argv[]){
	struct sockaddr_in sin;
	int fd=socket(AF_INET,SOCK_DGRAM,0);
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SERVER_PORT);
	sin.sin_addr.s_addr=inet_addr(SERVER_ADDR);
	bind(fd,(struct sockaddr*)&sin,sizeof(sin));
	work(fd,argv[1],strlen(argv[1]));
	close(fd);
	}

