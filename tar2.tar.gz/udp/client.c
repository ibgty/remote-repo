#include"net.h"
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
void main(){
	int fd=socket(AF_INET,SOCK_DGRAM,0);
	int ret;
	perror("");
	char buf[10];
	struct sockaddr_in server;
	server.sin_family=AF_INET;
	server.sin_port=htons(SERVER_PORT);
	server.sin_addr.s_addr=inet_addr(SERVER_ADDR);
	socklen_t len=sizeof(struct sockaddr);
	char addr[100];
		char buff[10]="123456789";
	while(1){
		sendto(fd,buff,sizeof(buff),0,(struct sockaddr*)&server,sizeof(struct sockaddr));
		printf("send %s\n",buff);
	do{
		ret=recvfrom(fd,buf,sizeof(buf),0,(struct sockaddr*)&server,&len);
	}while(ret<0);
		if(!ret){
			perror("recv");
			exit(1);
		}
		inet_ntop(AF_INET,(struct sockaddr*)&server.sin_addr.s_addr,addr,sizeof(struct sockaddr));
		printf("data:%s,port:%d,addr:%s\n",buf,ntohs(server.sin_port),addr);
		}
	close(fd);
}
		
