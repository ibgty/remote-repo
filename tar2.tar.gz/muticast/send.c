#include"net.h"
#include<string.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/wait.h>
void sigwork(int sig){
	if(SIGCHLD==sig){
		int state;
		waitpid(-1,&state,WNOHANG);
		printf("child process has exit ,code:%d\n",WEXITSTATUS(state));
	}
	if(SIGALRM==sig)
		return;
}
void main(void){
	struct sigaction act;
	int fd=socket(AF_INET,SOCK_DGRAM,0);
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(10000);
	sin.sin_addr.s_addr=htonl(INADDR_ANY);
	bind(fd,(struct sockaddr*)&sin,sizeof(sin));
	act.sa_handler=sigwork;
	sigemptyset(&act.sa_mask);
	act.sa_flags=0;
	sigaction(SIGCHLD,&act,NULL);
	int value=1;
	setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&value,sizeof(int));
	setsockopt(fd,SOL_SOCKET,SO_BROADCAST,&value,sizeof(int));
	fd_set set;
	FD_ZERO(&set);
	int pid=fork();
	char buf[10];
	if(pid<0){
		perror("fork");
	}
	if(0==pid){
		memset(buf,0,sizeof(buf));
				read(STDIN_FILENO,buf,sizeof(buf));
				printf("read:%s",buf);
		FD_SET(STDIN_FILENO,&set);
		if(0==strcmp(buf,"begin\n")){
			struct sockaddr_in sin;
			socklen_t len=sizeof(sin);
			while(1){
			select(fd+1,&set,NULL,NULL,NULL);
			if(FD_ISSET(fd,&set)){
				FD_SET(STDIN_FILENO,&set);
				recvfrom(fd,buf,sizeof(buf),0,(struct sockaddr*)&sin,&len);
				printf("receive:%s\n",buf);
				char*addr=inet_ntoa(sin.sin_addr);
				printf("ip:%s,port:%d\n",addr,htons(sin.sin_port));
				}
			if(FD_ISSET(STDIN_FILENO,&set)){
				read(STDIN_FILENO,buf,sizeof(buf));
				FD_SET(fd,&set);	
				printf("fgets:%s\n",buf);
				struct sockaddr_in boardcast;
				boardcast.sin_addr.s_addr=inet_addr(MUTICAST_ADDR);
				boardcast.sin_family=AF_INET;
				boardcast.sin_port=htons(20000);
				sendto(fd,buf,sizeof(buf),0,(struct sockaddr*)&boardcast,sizeof(boardcast));
				perror("");
				printf("send success\n");
			}
			}
		}
		else{
			goto quit;
		}
	}
	if(pid>0){
	while(1);
	}	
	quit:
			exit(EXIT_SUCCESS);
	}
