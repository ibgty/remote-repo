#ifndef _NET_H__
#define _NET_H__
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#define SEVER_ADDR "192.168.137.130"
#define MUTICAST_ADDR "239.0.0.1"
#define BOARDCAST_ADDR "192.168.137.255"
#define PORT 8051
#endif
