#ifndef __HEAD_H__
#define __HEAD_H__
#include<stdio.h>
void dop();
#endif
