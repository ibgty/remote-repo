#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/stat.h>
#define PATH "./fifo"
void main()
{	
	int fd;
	if(mkfifo(PATH,0666)<0){
		perror("mkfifo error");
		//exit(EXIT_FAILURE);
	}
	 if((fd=open(PATH,O_RDONLY|O_NONBLOCK))<0){
                perror("mkfifo error");
                exit(EXIT_FAILURE);
        }
	 char*buf=(char*)malloc(sizeof(char)*100);
	 if(read(fd,buf,sizeof(char)*64)<0){
                perror("mkfifo error");
                exit(EXIT_FAILURE);
        }
	printf("%s\n",buf);	 
        close(fd);
	exit(EXIT_SUCCESS);
}
