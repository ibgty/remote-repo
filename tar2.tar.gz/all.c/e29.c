#include<pthread.h>
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
void* routine(void* arg){
while(1){
	sleep(1);
	//pthread_detach(pthread_self());
	printf("pthrea%d\n",(int)arg);
	pthread_exit("return");
	break;
}
}
void main(){
	int arg=5;
	void *ret;
	printf("before\n");
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	pthread_t tid;
	pthread_create(&tid,NULL,routine,arg);
	pthread_join(tid,&ret);
	printf("thread=%s\n",(char*)ret);
	while(1){
		sleep(1);
	}
}
