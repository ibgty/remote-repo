#include<unistd.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/stat.h>
#define PATH "./fifo"
void main()
{	
	int fd;
	if(mkfifo(PATH,0666)<0){
		perror("mkfifo error");
		//exit(EXIT_FAILURE);
	}
	 if((fd=open(PATH,O_WRONLY|O_NONBLOCK))<0){
                perror("mkfifo error");
                exit(EXIT_FAILURE);
        }
	 char*buf=(char*)malloc(sizeof(char)*100);
	 strcpy(buf,"hello world");
	 if(write(fd,buf,strlen(buf)+1)<0){
                perror("mkfifo error");
                exit(EXIT_FAILURE);
        }
  	printf("success\n");	 
        close(fd);
	//exit(EXIT_SUCCESS);
}
