#include<stdio.h>
void fun(){
	printf("hello\n");
}
