#ifndef __HEAD_H__
#define __HEAD_H__
#include<stdio.h>
printf("hello world\n");
#endif
