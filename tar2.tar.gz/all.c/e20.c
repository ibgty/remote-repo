#include"head.h"
void main(){
	dop();
}
