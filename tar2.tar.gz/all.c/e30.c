#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<pthread.h>

pthread_rwlock_t rwlock;
FILE*fp;
#include<string.h>
pthread_mutex_t mutex1;
pthread_mutex_t mutex2;
void*fun1(void* arg){
	char* str="write1\n";
	int i=0;
	char c;
	char buf[30]={0};

	while(1){
	//pthread_mutex_lock(&mutex1);
	pthread_rwlock_rdlock(&rwlock);
	/*while(i<strlen(str)){
		int j=0;
		c=str[i];
		j=fputc(c,fp);
		if(j<0)
			perror("1fputc");
		i++;
		usleep(1);	
	}*/
	while(fgets(buf,30,fp)!=NULL){
		printf("%s\n",buf);
	}
	pthread_rwlock_unlock(&rwlock);
	//pthread_mutex_unlock(&mutex1);
	i=0;
	sleep(1);
	}
	pthread_exit(NULL);
	pthread_cleanup_push(NULL,NULL);
	pthread_teatcancel();
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);
	pthread_cleanup_pop(0);
}	
void*fun2(void* arg){
	pthread_detach(pthread_self());
        char* str="write2\n";
        int i=0;
        char c;
        while(1){
	//pthread_mutex_lock(&mutex1);
	pthread_rwlock_wrlock(&rwlock);
        while(i<strlen(str)){
		int j=0;
                c=str[i];
               j= fputc(c,fp);
	       if(j<0)
		       perror("2fputc");
                i++;
                usleep(1);
        }
	//pthread_mutex_unlock(&mutex1);
	pthread_rwlock_unlock(&rwlock);
        i=0;
	usleep(1);
        }
	pthread_exit(NULL);
}


void main(){
	pthread_t tid[4];
	pthread_attr_t attr;
	pthread_rwlock_t rwlock;
	pthread_mutex_init(&mutex1,NULL);
	pthread_mutex_init(&mutex2,NULL);
	pthread_rwlock_init(&rwlock,NULL);
	fp=fopen("1.txt","a+");
	if(fp==NULL){
		perror("fopen");
	}
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	
	pthread_create(&tid[0],&attr,fun1,1);
	usleep(1);
	pthread_create(&tid[1],&attr,fun2,2);
	for(int i=0;i<2;i++){
	pthread_join(tid[i],NULL);
	}
	while(1){
		sleep(1);
	}
	pthread_cancel(tid[0]);
	pthread_cancel(tid[1]);
}
