#include<stdio.h>
#include<unistd.h>
void main(){
	if(execlp("ls","sfds","-a",NULL)<0)
		perror("execl");
	printf("ok\n");
}
