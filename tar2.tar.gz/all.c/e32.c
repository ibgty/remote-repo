#include<stdio.h>
#include<unistd.h>
#include<pthread.h>
pthread_t tid[2];
void* fun(void* arg)
{
	pthread_detach(tid[(int)arg]);
	printf("thread %d\n",(int)arg);
	printf("aaaa\n");
	printf("bbbb\n");
	pthread_exit(0);
}
void main(){
	pthread_create(&tid[0],NULL,fun,0);
	pthread_create(&tid[1],NULL,fun,1);
	while(1){
		sleep(1);
	}
}
