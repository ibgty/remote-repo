#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
void main(){
	printf("before\n");
	pid_t pid;
	pid=fork();
	if(pid>0){
		while(1){
		printf("father\n");
		sleep(3);
		}
	}
	else if(pid==0){
		while(1){
		sleep(3);
		printf("child\n");
		}
	}
}
