#include<stdio.h>
void main()
{
	int a=0;
	int*b=&a;
	void*c=(void*)b;
	char*d=(char*)b;
	long long int* e=(long long int*)b;
	printf("%ud\n",b);
	printf("%ud\n",c);
	printf("%ud\n",d);
	printf("%ld\n",e);
}
