#include"hello.h"
void main(){
	fun();
}
