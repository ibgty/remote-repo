#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#define PATH "."
#define PRO 66
typedef struct msg{
	long mtype;
	char mtext[72];
}msgbuf;

void main(){
	msgbuf buf;
	buf.mtype=101;
	int key=ftok(PATH,PRO);
	int msgid=msgget(key,IPC_CREAT|0666);
	ssize_t ret=msgrcv(msgid,(void*)&buf,72,101,0);
	if(-1==ret)
	perror("error");
	printf("receive %s\n",buf.mtext);
	msgctl(msgid,IPC_RMID,NULL);
}
