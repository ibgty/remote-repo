#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<semaphore.h>
#include<signal.h>
#include<stdlib.h>

void work(int sig){
	printf("delete read\n");
	sem_unlink("r");
	exit(0);
}
void main(){
	struct sigaction act;
	act.sa_handler=work;
	act.sa_flags=0;
	sigemptyset(&act.sa_mask);
	sigaction(SIGINT,&act,NULL);
	key_t key=ftok("1.txt",66);
	int i=shmget(key,1000,IPC_CREAT|0666);
	if(i<0)
	perror("shmget");
	void* a=shmat(i,NULL,0);
	if(((void*)-1)==a)
		perror("shmat");
	 sem_t* sem_r=sem_open("r",O_CREAT|O_RDWR,0666,0);
	sem_t* sem_w=sem_open("w",O_CREAT|O_RDWR,0666,1);
	while(1){
		sem_wait(sem_r);
		printf("read:%s\n",(char*)a);
		//fgets((char*)a,10,stdin);
		sem_post(sem_w);
	}	
}
