#include<unistd.h>
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
#include<stdlib.h>
void main(){
	int ret;
	int pipefd[2];
	pid_t pid;
	ret=pipe(pipefd);
	if(ret<0){
		perror("pipe error");
		exit(EXIT_FAILURE);
	}
	pid=fork();
	if(pid<0){
		perror("fork error");
		exit(EXIT_FAILURE);
	}
	if(pid==0){
		close(pipefd[0]);
		char* buf="hello world";
		write(pipefd[1],buf,strlen(buf));
		close(pipefd[1]);
		printf("send sucessully\n");
		exit(EXIT_SUCCESS);
	}
	if(pid>0)
	{
		close(pipefd[1]);
		char*buf;
		printf("wait\n");
		wait(NULL);
		read(pipefd[0],buf,100);
		printf("read:%s\n",buf);
		close(pipefd[0]);
		}
}
