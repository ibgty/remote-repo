#include<stdio.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<string.h>
#define PATH "."
#define PRO 66
void main(){
	key_t key=ftok(PATH,PRO);
	int shmid=shmget(key,2,IPC_CREAT|0666);
	void *p=shmat(shmid,NULL,0);
	if(p==(void*)-1){
		perror("error");
		exit(EXIT_FAILURE);
	}
	char buf[30];
	memcpy(buf,p,8);
	shmdt(p);
	printf("copy:%s\n",buf);
	for(int i=0;i<strlen(buf)+2;i++){
		printf("%d %c\t",i,buf[i]);
	}
	shmctl(shmid,IPC_RMID,NULL);
}
