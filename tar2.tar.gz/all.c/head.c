#include"head.h"
void dop(){
	printf("hello world\n");
}
