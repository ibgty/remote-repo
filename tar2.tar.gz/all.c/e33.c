#include<stdio.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>
#include<string.h>
#include<wait.h>
void do_usr_sig(int sig){
	//sleep(2);
	printf("receive <%s>\n",strsignal(sig));
	wait(NULL);
}

void main()
{
	if(signal(SIGCHLD,do_usr_sig)==SIG_ERR){
		perror("error");
		exit(EXIT_FAILURE);
	}
	pid_t pid;
	printf("begin\n");
	pid=fork();
	if(0==pid){
		printf("child begin\n");
		printf("pause\n");
		//pause();
		printf("pause end\n");
		exit(EXIT_SUCCESS);
	}
	if(pid>0)
	{
		sleep(1);
		printf("father begin\n");
		//kill(pid,SIGUSR1);
		printf("kill end\n");
		while(1){
			sleep(1);
		}
	}
}
