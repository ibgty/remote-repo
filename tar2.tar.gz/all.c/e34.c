#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<string.h>
#define PATH "."
#define PRO 66
typedef struct msg{
	long mtype;
	char mtext[64];
}msgbuf;
void main(){
	msgbuf buf;
	buf.mtype=101;
	strcpy(buf.mtext,"hello world");
	key_t key=ftok(PATH,PRO);
	int msgid=msgget(key,IPC_CREAT|0666);
	int ret=msgsnd(msgid,(const void*)&buf,sizeof(buf),0);
	if(-1==ret)
	{
		perror("error");
	}
}
