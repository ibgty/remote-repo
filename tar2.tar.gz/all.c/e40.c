#include<stdio.h>
#include<stdlib.h>
#include<sys/mman.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<signal.h>
#include<sys/wait.h>
void do_sig(int sig){
	int w;
	printf("success\n");
	wait(&w);
	printf("wait:%d\n",WEXITSTATUS(w));
}
void main(){
	int fd=open("1.txt",O_RDWR|O_CREAT);
	if(fd<0){
	perror("open");
	return;
	}
	//off_t len=lseek(fd,0,SEEK_END);
	//printf("len:%ld\n",len);
	void *addr=mmap(NULL,100,PROT_WRITE|PROT_READ,MAP_SHARED|MAP_ANONYMOUS,-1,0);
	if(addr==MAP_FAILED){
		perror("map");
		return;
	}
	__sighandler_t sig=signal(SIGCHLD,do_sig);
	if(sig==SIG_ERR){
		perror("signal");
	}
	pid_t pid=fork();
	if(pid==0){
	char str[100]="hello world";
	memcpy(addr,str,strlen(str));
	
	exit(EXIT_SUCCESS);
	}
	if(pid>0){
		sleep(1);
		char str[100];
		memcpy(str,addr,strlen(addr));
		printf("cpy:%s\n",str);
	}
	//char str[100];
	//memcpy(str,addr,100);
	//close(fd);
	//printf("addr:%s\n",(char*)str);
}
