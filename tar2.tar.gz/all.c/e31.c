#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

typedef struct node{
	int  num;
	struct node* next;
}taxi;
taxi* head=NULL;
pthread_cond_t cond=PTHREAD_COND_INITIALIZER;
pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;

void* taxicome(void *arg){
	printf("taxi arrived thread\n");
	taxi*temp;
	pthread_detach(pthread_self());
	int i=0;
	while(1){
	temp=(taxi*)malloc(sizeof(taxi));
	pthread_mutex_lock(&lock);
	temp->next=head;
	temp->num=++i;
	head=temp;
	printf("taxi %d comming\n",temp->num);
	pthread_cond_broadcast(&cond);
	pthread_mutex_unlock(&lock);
	sleep(1);
	}
	pthread_exit(0);
}
void* passager(void* arg){
	taxi*temp;
	pthread_detach(pthread_self());
	printf("take taxi thread\n");
	while(1){
	pthread_mutex_lock(&lock);
	while(head==NULL)
		pthread_cond_wait(&cond,&lock);
	temp=head;
	head=temp->next;
	temp->next=NULL;
	printf("%d,take taxi %d\n",(int)arg,temp->num);
	free(temp);
	pthread_mutex_unlock(&lock);
	}
	pthread_exit(0);
}
void main(){
	pthread_t tid[3];
	pthread_create(&tid[0],NULL,taxicome,(void*)0);
	pthread_create(&tid[1],NULL,passager,(void*)2);
	pthread_create(&tid[2],NULL,passager,(void*)1);
	while(1)
		sleep(1);
}
