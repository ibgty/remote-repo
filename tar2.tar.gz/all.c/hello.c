#include<stdio.h>
void fun(){
	printf("hello\n");
}
void main(){
	fun();
	
	printf("1");
	
	
		printf("world\n");
	
	
}
