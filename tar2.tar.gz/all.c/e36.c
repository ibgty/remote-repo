#include<stdio.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<string.h>
#define PATH "."
#define PRO 66
void main(){
	key_t key=ftok(PATH,PRO);
	int shmid=shmget(key,256,IPC_CREAT|0666);
	void *p=shmat(shmid,NULL,0);
	if(p==(void*)-1){
		perror("error");
		exit(EXIT_FAILURE);
	}
	memset(p,'a',10);
	shmdt(p);
}
