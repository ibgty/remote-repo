#include<stdio.h>
#include<string.h>
#define test() printf("1\n");
#define log(fm,...) printf(fm,__VA_ARGS__);
void main(){
	char a[12]="wel";
	char b[12];
	log("test,%d\n",2,3);
	char*c=a;
	strcpy(b,c);
	for(int i=0;i<10;i++)
		printf("%d\n",b[i]);





}
