#include<stdio.h>
#include<stdlib.h>
#include<sys/mman.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
void main(){
	int fd=open("1.txt",O_RDWR|O_CREAT);
	if(fd<0){
	perror("open");
	return;
	}
	//off_t len=lseek(fd,0,SEEK_END);
	//printf("len:%ld\n",len);
	void *addr=mmap(NULL,100,PROT_WRITE|PROT_READ,MAP_SHARED,fd,0);
	if(addr==MAP_FAILED){
		perror("map");
		return;
	}
	char str[100];
	memcpy(str,addr,100);
	//close(fd);
	printf("addr:%s\n",(char*)str);
}
