#include<stdio.h>
#include<unistd.h>
#include<signal.h>
#include<sys/time.h>

void work(int sig){
	if(sig==SIGALRM)
		printf("on time\n");
	else if(sig==SIGINT)
		printf("c:%d\n",SIGINT);
}
void main(){
	struct itimerval value;
	value.it_interval.tv_sec=2;
	value.it_interval.tv_usec=0;
	value.it_value.tv_sec=2;
	value.it_value.tv_usec=2;
	setitimer(ITIMER_REAL,&value,NULL);
	struct sigaction act;
	act.sa_handler=work;
	act.sa_flags=0;
	sigemptyset(&act.sa_mask);
	sigaction(SIGALRM,&act,NULL);
	
	sigaction(SIGINT,&act,NULL);
	while(1)
		sleep(1);
}
