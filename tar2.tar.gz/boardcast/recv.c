#include"net.h"
#include<string.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/wait.h>
void sigwork(int sig){
	if(SIGCHLD==sig){
		int state;
		waitpid(-1,&state,WNOHANG);
		printf("child process has exit ,code:%d\n",WEXITSTATUS(state));
	}
	if(SIGALRM==sig)
		return;
}
void main(void){
	struct sigaction act;
	struct sockaddr_in cin;
	int fd=socket(AF_INET,SOCK_DGRAM,0);
	cin.sin_family=AF_INET;
	cin.sin_port=htons(20000);
	cin.sin_addr.s_addr=htonl(INADDR_ANY);
	bind(fd,(struct sockaddr*)&cin,sizeof(cin));
	act.sa_handler=sigwork;
	sigemptyset(&act.sa_mask);
	act.sa_flags=0;
	sigaction(SIGCHLD,&act,NULL);
	int value=1;
	setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&value,sizeof(int));
	setsockopt(fd,SOL_SOCKET,SO_BROADCAST,&value,sizeof(int));
	fd_set set;
	FD_ZERO(&set);
	int pid=fork();
	char buf[10];
	if(pid<0){
		perror("fork");
	}
	if(0==pid){
		FD_SET(fd,&set);
			struct sockaddr_in sin;
			socklen_t len=sizeof(sin);
			while(1){
			select(fd+1,&set,NULL,NULL,NULL);
			if(FD_ISSET(fd,&set)){
				FD_SET(STDIN_FILENO,&set);
				recvfrom(fd,buf,sizeof(buf),0,(struct sockaddr*)&sin,&len);
				printf("receive:%s\n",buf);
				char*addr=inet_ntoa(sin.sin_addr);
				printf("ip:%s,port:%d\n",addr,htons(sin.sin_port));
				}
			if(FD_ISSET(STDIN_FILENO,&set)){
				fgets(buf,sizeof(buf),stdin);
				FD_SET(fd,&set);	
				printf("fgets:%s\n",buf);
				struct sockaddr_in boardcast;
				boardcast.sin_addr.s_addr=inet_addr(BOARDCAST_ADDR);
				boardcast.sin_family=AF_INET;
				boardcast.sin_port=htons(10000);
				sendto(fd,buf,sizeof(buf),0,(struct sockaddr*)&boardcast,sizeof(boardcast));
				printf("send success\n");
			}
			}
	}
	if(pid>0){
	while(1);
	}	
	}
