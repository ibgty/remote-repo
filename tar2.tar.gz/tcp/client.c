#include "net.h"

void main(){
	int fd=socket(AF_INET,SOCK_STREAM,0);
	int b_reuse=1;
	setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&b_reuse,sizeof(int));
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
	inet_pton(AF_INET,SIN_IP,&sin.sin_addr);
	connect(fd,(struct sockaddr*)&sin,sizeof(struct sockaddr));
	perror("");
	char buf[100];
	int ret;
	while(1){
		bzero(buf,sizeof(buf));
		//fgets(buf,sizeof(buf),stdin);
		
		//	ret=write(fd,buf,strlen(buf));
		do{
		ret=read(fd,buf,sizeof(buf));
		}while(ret<0);
		printf("receive:%s\n",buf);
		if(!strncasecmp(buf,"quit",strlen("quit")))
				break;
		}
		perror("");
		close(fd);
	}

