#include"net.h"
#include<unistd.h>
#include<sys/select.h>
#include<pthread.h>
#include<fcntl.h>
int newfd=-1;
int maxfd=-1;
fd_set rset;
int temp[2];
typedef struct {
	int fdw;
	int i;
}some;
#if 1
void acc(void*fde){
	int ret;
	char buf[100];
	struct sockaddr_in cin;
	socklen_t cinlen=sizeof(struct sockaddr_in);
	char buff[100];
	some* p=(some*)fde;
	int fd=p->fdw;
	int j=p->i;
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	if(maxfd<newfd)
	maxfd=newfd;
	temp[j]=newfd;
	int flag=fcntl(newfd,F_GETFL,0);
	flag|=O_NONBLOCK;
	fcntl(newfd,F_SETFL,flag);
	FD_ZERO(&rset);
	FD_SET(newfd,&rset);
while(1){
	select(maxfd+1,&rset,NULL,NULL,NULL);
	if(FD_ISSET(temp[0],&rset)){
			do{
			ret=read(temp[0],buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
	printf("read:%s",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	if(FD_ISSET(newfd,&rset)){
			do{
			ret=read(temp[1],buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
			
	printf("read:%s\n",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	}
}
#else
	pid_t pid=fork();
	if(pid<0)
		exit(1);
	else if(0==pid){
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	work((void*)newfd);
	}
	else if(pid>0){
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	work((void*)newfd);
	}
#endif
#if 1
void work(void *arg){
	int ret;
	int fd=(int)arg;
	char buf[100];
	while(1){
		do{
			ret=read(fd,buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
	printf("read:%s",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
}	
#else
void work(void *arg){
	int ret;
	int fd=(int)arg;
	char buf[100];
	while(1){
			fgets(buf,sizeof(buf)-1,stdin);
		do{
			ret=write(fd,buf,strlen(buf));
		}while(ret<0&&EINTR==errno);
	printf("write:%s",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
}	
#endif
void main(){
	pthread_t tid[2];
	pthread_t td[2];
	int fd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
	if(inet_pton(AF_INET,SIN_IP,&sin.sin_addr)!=1){
		perror("");
		exit(1);
	}
	bind(fd,(struct sockaddr*)&sin,sizeof(sin));
	listen(fd,BACKLOG);
	some a,b;
	a.fdw=fd;	
	b.fdw=fd;
	a.i=0;
	b.i=1;
	FD_ZERO(&rset);	
#if 1
	pthread_create(&td[0],NULL,(void*)acc,(void*)&a);
	pthread_create(&td[1],NULL,(void*)acc,(void*)&b);
	int ret;
	char buf[100];
	while(1){
	select(maxfd+1,&rset,NULL,NULL,NULL);
	if(FD_ISSET(temp[0],&rset)){
			do{
			ret=read(temp[0],buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
	printf("read:%s",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	if(FD_ISSET(newfd,&rset)){
			do{
			ret=read(temp[1],buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
			
				break;
	printf("read:%s\n",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	}
#else
	pid_t pid=fork();
	if(pid<0)
		exit(1);
	else if(0==pid){
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	work((void*)newfd);
	}
	else if(pid>0){
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	work((void*)newfd);
	}
#endif
	close(newfd);
	close(fd);
}
