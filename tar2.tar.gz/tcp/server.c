#include"net.h"

void main(){
	int fd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
	if(inet_pton(AF_INET,SIN_IP,&sin.sin_addr)!=1){
		perror("");
		exit(1);
	}
	bind(fd,(struct sockaddr*)&sin,sizeof(sin));
	listen(fd,BACKLOG);
	int newfd=-1;
	struct sockaddr_in cin;
	socklen_t cinlen=sizeof(struct sockaddr_in);
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	char buff[100];
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	int ret;
			char buf[100];
	while(1){
			memset(buf,0,sizeof(buf));
			fgets(buf,sizeof(buf)-1,stdin);
		do{
			//ret=read(newfd,buf,sizeof(buf));
			ret=write(newfd,buf,strlen(buf));
			
		}while(ret<0&&EINTR==errno);
	if(ret==0)
	break;
	printf("receive:%s",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	perror("");
	close(newfd);
	close(fd);
}	
