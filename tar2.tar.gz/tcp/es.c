#include"net.h"
void main(){
	int sd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
#if 0
	if(inet_pton(AF_INET,SIN_ADDR,&sin.sin_addr)!=1)
		exit(0);
#else
	sin.sin_addr.s_addr=htonl(INADDR_ANY);
#endif
	bind(sd,(struct sockaddr*)&sin,sizeof(sin));
	listen(sd,BACKLOG);
	struct sockaddr_in cin;
	cin.sin_family=AF_INET;
	cin.sin_port=htons(CIN_PORT);
	inet_pton(AF_INET,CIN_IP,&(cin.sin_addr));
	socklen_t len=sizeof(cin);
	int newfd=accept(sd,(struct sockaddr*)&cin,&len);
	if(newfd<0)
		perror("");
	int ret;
	char wbuff[100];
	char buff[100];
	while(1){
		memset(buff,0,sizeof(buff));
		do{
		ret=read(newfd,buff,sizeof(buff)-1);
		}while(ret<0&&EINTR==errno);
		printf("read %s",buff);
		memset(wbuff,0,sizeof(wbuff));
		while(fgets(wbuff,sizeof(wbuff)-1,stdin)==NULL);
		do{ret=write(newfd,wbuff,sizeof(wbuff)-1);
		}while(ret<0&&EINTR==errno);
		printf("write %s",wbuff);
	}
	close(newfd);
	close(sd);
}	
			

