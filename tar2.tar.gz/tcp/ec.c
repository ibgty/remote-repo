#include"net.h"
void main(){
	int sd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
	inet_aton(SIN_IP,&sin.sin_addr);
	connect(sd,(struct sockaddr*)&sin,sizeof(sin));
	perror("connect");
	char buff[100];
	char rbuff[100];
	int ret;
	while(1){
		memset(buff,0,sizeof(buff));
		memset(rbuff,0,sizeof(rbuff));
		fgets(buff,sizeof(buff)-1,stdin);
		do{
			ret=write(sd,buff,sizeof(buff)-1);
		}while(ret<0&&EINTR==errno);
		printf("write %s\n",buff);
		do{
			ret=read(sd,rbuff,sizeof(rbuff)-1);
		}while(ret<0&&EINTR==errno);
		printf("read %s\n",rbuff);
	}
	close(sd);
}

		
