#ifndef __NET_H__
#define __NET_H__
#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>
#include<errno.h>
#define SIN_PORT 5003
#define CIN_PORT 5005
#define CIN_IP "192.168.137.130"
#define SIN_IP "192.168.137.130"
#define BACKLOG 5
#endif
