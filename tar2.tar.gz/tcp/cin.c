#include "net.h"
void work(int fd){
	char buf[100];
	int ret;
	while(1){
		bzero(buf,sizeof(buf));
		fgets(buf,sizeof(buf)-1,stdin);
		do{
		ret=write(fd,buf,sizeof(buf));
		}while(ret<0);
		printf("write:%s\n",buf);
		if(!strncasecmp(buf,"quit",strlen("quit")))
				break;
	}
}
void main(){
	int fd=socket(AF_INET,SOCK_STREAM,0);
	int b_reuse=1;
	setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&b_reuse,sizeof(int));
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
	inet_pton(AF_INET,SIN_IP,&sin.sin_addr);
	connect(fd,(struct sockaddr*)&sin,sizeof(struct sockaddr));
	perror("");
	work(fd);
	close(fd);
}
