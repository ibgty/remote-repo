#include"net.h"
#include<unistd.h>
#include<sys/select.h>
#include<pthread.h>
#include<fcntl.h>
int newfd=-1;
int maxfd=-1;
fd_set rset;
int temp[2];
typedef struct {
	int fdw;
	int i;
}some;
void acc(void*fde){
	int ret;
	char buf[100];
	struct sockaddr_in cin;
	socklen_t cinlen=sizeof(struct sockaddr_in);
	char buff[100];
	some* p=(some*)fde;
	int fd=p->fdw;
	int j=p->i;
	newfd=accept(fd,(struct sockaddr*)&cin,&cinlen);
	inet_ntop(AF_INET,&cin.sin_addr,buff,sizeof(buff));
	printf("ip:%s,port:%d\n",buff,ntohs(cin.sin_port));
	if(maxfd<newfd)
	maxfd=newfd;
	temp[j]=newfd;
	int flag=fcntl(newfd,F_GETFL,0);
	flag|=O_NONBLOCK;
	fcntl(newfd,F_SETFL,flag);
	FD_SET(newfd,&rset);
}
void main(){
	pthread_t tid[2];
	pthread_t td[2];
	int fd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SIN_PORT);
	if(inet_pton(AF_INET,SIN_IP,&sin.sin_addr)!=1){
		perror("");
		exit(1);
	}
	bind(fd,(struct sockaddr*)&sin,sizeof(sin));
	listen(fd,BACKLOG);
	some a,b;
	a.fdw=fd;	
	b.fdw=fd;
	a.i=0;
	b.i=1;
	FD_ZERO(&rset);	
	pthread_create(&td[0],NULL,(void*)acc,(void*)&a);
	pthread_create(&td[1],NULL,(void*)acc,(void*)&b);
	sleep(5);
	int ret;
	char buf[100];
	while(1){
		printf("select\n");
	select(maxfd+1,&rset,NULL,NULL,NULL);
	sleep(5);
	if(FD_ISSET(temp[0],&rset)){
			do{
			ret=read(temp[0],buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
	printf("read:%s",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	if(FD_ISSET(temp[1],&rset)){
			do{
			ret=read(temp[1],buf,sizeof(buf));
		}while(ret<0&&EINTR==errno);
	printf("read:%s\n",buf);
	if(!strncasecmp(buf,"quit",strlen("quit")))
	break;
	}
	}
	close(newfd);
	close(fd);
}
//try mutex to imporve
//try increase signal to recycle
