#include"sem.h"
#include<stdio.h>
#include<unistd.h>
void main(){
	unsigned short value[2]={1,0};
	int semid=create_sem(2,value);
	pid_t pid=fork();
	if(0==pid){
		while(1){
		sem_p(semid,1);
		printf("B");
		fflush(stdout);
		sem_v(semid,0);
		}
	}else if(pid>0){
		while(1){
		sem_p(semid,0);
		printf("A");
		fflush(stdout);
		sem_v(semid,1);
		sem_p(semid,0);
		printf("A");
		fflush(stdout);
		putchar('\n');
		sleep(1);
		sem_v(semid,0);
		}
	}

}
