#ifndef __SEM_H__
#define __SEM_H__
#define PATH "."
#define ID 66
typedef union semun{
	unsigned short *array;
}sem;
int create_sem(int ,unsigned short*);
int sem_p(int semid,int semnum);
int sem_v(int semid,int semnum);
int sem_del(int semid);
#endif
