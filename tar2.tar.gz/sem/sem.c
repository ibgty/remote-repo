#include"sem.h"
#include<stdio.h>
#include<sys/sem.h>
#include<stdlib.h>
int create_sem(int  nsems,unsigned short* value){
	key_t key=ftok(PATH,ID);
	int semid=semget(key,nsems,IPC_CREAT|0666);	if(semid==-1){
		perror("semget");
		exit(0);
	}
	sem s;
	int ret;
	s.array=value;
	ret=semctl(semid,0,SETALL,s);
	if(-1==ret){
		perror("semctl");
	}
	return semid;
}
int sem_p(int semid,int semnum){
	struct sembuf sops;
	sops.sem_num=semnum;
	sops.sem_op=-1;
	sops.sem_flg=SEM_UNDO;
	return semop(semid,&sops,1);
}
int sem_v(int semid,int semnum){
	struct sembuf sops;
	sops.sem_num=semnum;
	sops.sem_op=1;
	sops.sem_flg=SEM_UNDO;
	return semop(semid,&sops,1);
}
int sem_del(int semid){
	return semctl(semid,0,IPC_RMID,NULL);
}
