#include<stdio.h>
#include<sys/stat.h>
int main(int argc ,int argv[]){
	int ret;
	ret=chmod("temp",0777);
	if(ret<0)
		perror("");
}
