#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
///int a=0;
void main(){
	int a=0;
	pid_t pid;
	pid=fork();
	while(1){
		a++;

	//for(int i=0;i<3;i++)
	printf("%d\n",a);
		sleep(2);
	}
	printf("hello");

}
