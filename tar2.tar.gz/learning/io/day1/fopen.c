#include<stdio.h>
#include<errno.h>
#include<string.h>
int main(int argc, char *argv[]){
	FILE *fp;
	int fpret;
	fp=fopen("1.txt","w+");
	if(NULL==fp){
		perror("open:");
		printf("open file failed\n");
		printf("fopen:%s\n",strerror(errno));
	}else{
		printf("open file success\n");
	}
	fpret=fclose(fp);
	//fpret=fclose(fp);

	if(0==fpret){
		printf("file close success\n");
	}else{
		printf("close failed\n");
	}

	
}
