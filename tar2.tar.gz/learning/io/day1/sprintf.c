#include<stdio.h>
int main(int argc,char*argv[]){
	char buf[100]={0};
	int year=2024;
	int month=5;
	int day=1;
	sprintf(buf,"%d-%d-%d",year,month,day);
	printf("%s\n",buf);
	sscanf(buf,"%d-%d-%d",&year,&month,&day);
	printf("%d%d%d\n",year,month,day);
	FILE*fp;
	fp=fopen("1.txt","r+");
	size_t ret;
	char buff2[5]="4-5-1";
	ret=fwrite(buff2,5,1,fp);
	if(-1==ret){
		perror("");
		return 0;
	}
	rewind(fp);
	long f;
	f=ftell(fp);
	fscanf(fp,"%d-%d-%d",&year,&month,&day);
	printf("%ld,%d,%d,%d\n",f,year,month,day);
}
