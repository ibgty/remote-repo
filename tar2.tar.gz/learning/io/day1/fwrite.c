#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct student{
	char name[9];
	int age;
	char sex[4];
};
int main(int argc,char*argv[]){
	FILE*fp;
	char*buff;
	size_t ret;
	struct student stu;
	fp=fopen("1.bin","w");
	strcpy(stu.name,"zhangsan");
	strcpy(stu.sex,"nan");
	stu.age=11;
	//buff=(char*)malloc(100);
	ret=fwrite(&stu,sizeof(stu),1,fp);
	if(-1==ret){
		perror("");
		goto end;
	}
end:
	fclose(fp);
	//free(buff);
}
