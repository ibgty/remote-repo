#include<stdio.h>
int main(int argc,char* argv[]){
	FILE* fp;
	char *ret;
	char buff[100];
	fp=fopen("1.txt","r");
	if(NULL==fp){
		perror("fopen");
		return 0;
	}
	ret=fgets(buff,2,fp);
	if(NULL==ret){
		perror("fgets");
		fclose(fp);
		return 0;
	}
	printf("buff=%s\n",buff);
	ret=fgets(buff,2,fp);
        if(NULL==ret){
                perror("fgets");
                fclose(fp);
                return 0;
        }
        printf("buff=%s\n",buff);
ret=fgets(buff,2,fp);
        if(NULL==ret){
                perror("fgets");
                fclose(fp);
                return 0;
        }
        printf("buff=%s\n",buff);
	
}
