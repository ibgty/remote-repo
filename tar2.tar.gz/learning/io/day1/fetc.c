#include<stdio.h>
int main(int argc,char *argv[]){
	FILE*fp;
	int rec;
	fp=fopen("1.txt","r+");
	if(NULL==fp){
		perror("fopen");
		return 0;
	}
	rec=fgetc(fp);
	printf("char=%c\n",rec);
	int a;
	//a=fclose(fp);
	/*if(EOF==a){
		perror("");
	}*/
	rec=fgetc(fp);
	printf("char=%c\n",rec);
	rec=getchar();
	printf("char=%c\n",rec);
	int  w='w';
	rec=fputc(w,fp);
	if(-1==rec){
		perror("fputc");
	}
	else{
		printf("success\n");
	}
}
