#include<stdio.h>
#include<unistd.h>
int main()
{
	printf("1\n");
	while(1){
	//sleep(1);
	printf("1");
	}
	return 0;
}
