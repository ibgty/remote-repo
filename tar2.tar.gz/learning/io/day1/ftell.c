#include<stdio.h>
int main(int argc,char* argv[]){
	FILE*fp;
	fp=fopen("1.txt","w");
	if(NULL==fp){
		perror("fopen");
		return 0;
	}
	fwrite("ads",3,1,fp);
	rewind(fp);
	fwrite("vvv",3,1,fp);
	int a;
	a=ftell(fp);
	printf("ftell=%d",a);
}
