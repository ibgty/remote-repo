#include<stdio.h>
#include<unistd.h>
int main(int argc,char*argv[]){
	FILE*fp;
	fp=fopen("1.txt","w");
	if(NULL==fp){
		perror("fopen");
		return 0;
	}
	fwrite("basdw",3,1,fp);
	fflush(fp);
	while(1){
		sleep(1);
	}
}
