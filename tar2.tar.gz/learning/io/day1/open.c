#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
int main(int argc,char*argv[]){
	int fd;
	fd=open("1.txt",O_WRONLY|O_CREAT|O_TRUNC,0666);
	if(fd<0){
		perror("");
	}
	printf("success");
	int ret;
	//ret=close(fd);
	char buf[32]="hello world";
	ret=write(fd,buf,strlen(buf));
	if(ret<0){
	perror("");
	goto END;
	}
	close(fd);
	fd=open("1.txt",O_RDWR|O_CREAT|O_APPEND,0666);
	char buf2[32];
	ret=read(fd,buf2,strlen(buf));
	if(ret<0){
	perror("");
	goto END;
	}
	ret=lseek(fd,0,SEEK_SET);
	printf("%d\n",ret);
	printf("%s\n",buf2);
	ret=close(fd);
	if(ret<0){
	perror("");
	}
	else
		printf("success\n");
END:
	return 0;
}
