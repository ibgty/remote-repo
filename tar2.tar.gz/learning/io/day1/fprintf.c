#include<stdio.h>
int main(int argc,char*argv[]){
	FILE*fp;
	int year=2024;
	int month=5;
	int day=1;
	fp=fopen("1.txt","w");
	if(NULL==fp){
	perror("fopen");
	return 0;
	}
	fprintf(fp,"%d-%d-%d\n",year,month,day);
	fclose(fp);
}
