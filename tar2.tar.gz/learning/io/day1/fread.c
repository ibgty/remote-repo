#include<stdlib.h>
#include<stdio.h>
int main(int argc,char* argv[]){
	FILE*fp;
	char*buff;
	size_t ret;
	fp=fopen("1.txt","r");
	if(NULL==fp){
		perror("fopen:");
	}
	buff=(char*)malloc(10*sizeof(char));
	ret=fread(buff,5,1,fp);
	if(-1==ret){
		perror("fread");
	}
	printf("fread:%s\n",buff);
	printf("size=%ld\n",sizeof(char));
	free(buff);
	fclose(fp);
}
