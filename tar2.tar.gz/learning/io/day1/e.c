#include<time.h>
#include<stdio.h>
#include<unistd.h>
int main(int argc,char*argv[]){
	int line=0;
	FILE*fp;
	fp=fopen("1.txt","w+");
	char buff[32];
	while(NULL!=fgets(buff,32,fp)){
		line++;
	}
	time_t now;
	now=time(NULL);
	struct tm* ntime;
	ntime=localtime(&now);
	while(1){
	fprintf(fp,"%d %d-%d-%d %d-%d-%d\n",line,ntime->tm_year+1900,ntime->tm_mon+1,ntime->tm_mday,ntime->tm_hour,ntime->tm_min,ntime->tm_sec);
	sleep(1);
	line++;
	fflush(fp);
	}
}
