#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/wait.h>
void main(){
	pid_t pid;
	char s[6];
	char* arg[3];
	scanf("%s",s);
	printf("%s",s);
	char *first=NULL,*other=NULL;
	first=strtok(s," ");
	arg[0]=first;
	other=strtok(NULL," ");
	if(other){
		arg[1]=other;
		arg[2]=NULL;
	}
	else{
		arg[1]=arg[2]=NULL;
	}
	pid=fork();
	if(0==pid){
	//printf("%s\n",first);
	//printf("%s\n",other);
	//execvp(first,arg);
	perror("");
	exit(1);
	}
	else if(pid>0){
		wait(NULL);
	}

}
