#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
void main(){
	pid_t pid_a;
	pid_t pid_b;
	pid_a=fork();
	if(0==pid_a){
		printf("a");
		sleep(1);
		exit(1);
	}
	else if(0<pid_a){
		pid_b=fork();
		printf("d\n");
		if(0==pid_b){
			printf("b");
			sleep(1);
			exit(2);
		}
		else if(0<pid_b){
			int sta=0;
			while(waitpid(pid_a,&sta,WNOHANG)==0);
			printf("%d\n",WEXITSTATUS(sta));
			while(waitpid(pid_b,&sta,WNOHANG)==0);
			printf("%d\n",WEXITSTATUS(sta));
			printf("c");	
		}
	}

}

